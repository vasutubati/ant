package com.passion4java.helloworld.ant;

public class AntHelloWorld {

	public static void main(String[] args) {
		System.out.println("This Project was build using Ant");
	}

}
